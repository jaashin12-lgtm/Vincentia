// Register GSAP plugin
gsap.registerPlugin(MorphSVGPlugin);

// Animation timeline for morphing waves
const tl = gsap.timeline({ repeat: -1, yoyo: true }); // Repeat forever and reverse each cycle

// Morph wave1 from group1 to group2 to group3 to group4
tl.to("#wave1", {
  duration: 3,
  morphSVG: {
    shape: "M244.8 106.51C113.367 389.01 413.453 917.51 364.3 917.51C315.146 917.51 19.7998 902.746 19.7998 670.51C19.7998 438.275 166.646 43.5098 215.8 43.5098C246.3 43.5101 375.8 -49.9893 244.8 106.51Z" // Wave1 path of group2
  },
  ease: "power1.inOut"
}).to("#wave1", {
  duration: 3,
  morphSVG: {
    shape: "M244.8 106.51C113.367 389.01 413.453 917.51 364.3 917.51C315.146 917.51 19.7998 902.746 19.7998 670.51C19.7998 438.275 166.646 43.5098 215.8 43.5098C246.3 43.5101 375.8 -49.9893 244.8 106.51Z" // Wave1 path of group3
  },
  ease: "power1.inOut"
}).to("#wave1", {
  duration: 3,
  morphSVG: {
    shape: "M351.515 99.9467C157.745 386.297 600.159 922 527.693 922C455.227 922 19.7998 907.035 19.7998 671.634C19.7998 436.233 236.294 36.0874 308.761 36.0874C353.727 36.0877 544.647 -58.686 351.515 99.9467Z" // Wave1 path of group4
  },
  ease: "power1.inOut"
});

   gsap.to("#wave2", {
     duration: 3,
     delay: 0.5, // Delays this wave's animation by 0.5s
     morphSVG: { shape: "#group2-wave2" }
   });